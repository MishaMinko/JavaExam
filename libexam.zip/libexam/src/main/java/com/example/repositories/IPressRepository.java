package com.example.repositories;

import com.example.models.Press;
import org.springframework.data.repository.CrudRepository;

public interface IPressRepository extends CrudRepository<Press, Long> {

}
